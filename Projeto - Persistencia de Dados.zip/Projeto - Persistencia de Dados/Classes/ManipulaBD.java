import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lab4 on 02/04/2018.
 */

public class ManipulaBD {
    private SQLiteDatabase bd;

    public ManipulaBD(Context ctx) {
        CriaBD auxBD = new CriaBD(ctx);
        bd = auxBD.getWritableDatabase();
    }

    /*
    *
    * @name inserir
    * @info  Inserir informações na tabela livro
    *
    */
    public void inserir(Livro livro) {
        ContentValues valores = new ContentValues();
        valores.put("titulo", livro.getTitulo());
        valores.put("tipo", livro.getTipo());
    }

    /*
    *
    * @name atualizar
    * @info  atualizar informações na tabela livro
    *
    */
    public void atualizar(Livro livro) {
        ContentValues valores = new ContentValues();
        valores.put("titulo", livro.getTitulo());
        valores.put("tipo", livro.getTipo());
        bd.update("livro", valores, "_id = ?",
            new String[]{""+livro.getId()} );
    }

    /*
    *
    * @name deletar
    * @info  deletar informações na tabela livro
    *
    */
    public void deletar(Livro livro) {
        bd.delete("livro", "_id ="+ livro.getId(), null);
    }

    /*
    *
    * @name Montar lista
    * @info  Monta lista de dados do banco
    *
    */
    public List<Livro> buscar() {
        List<Livro> list = new ArrayList<Livro>();
        String[] colunas = new String[]{"_id", "titulo", "tipo"};
        Cursor cursor = bd.query("livro", colunas, null, null, null, null, "titulo");

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            do {
                Livro i = new Livro();
                i.setId(cursor.getLong(0));
                i.setTitulo(cursor.getString(1));
                i.setTipo(cursor.getString(2));
                list.add(i);
            } while (cursor.moveToNext());
        }
        return(list);
    }
}
