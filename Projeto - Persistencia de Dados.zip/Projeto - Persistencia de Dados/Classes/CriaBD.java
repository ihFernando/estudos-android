import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by lab4 on 02/04/2018.
 */

public class CriaBD extends SQLiteOpenHelper {
    private static final String NOME_BD = "Mylib";
    private static final int VERSAO_BD = 1;

    public CriaBD(Context ctx){
        /* Construtor da classe mãe */
        super(ctx, NOME_BD, null, VERSAO_BD);
    }

    /*
    * @name onCreate
    * @info  Set a as regras SQL para manipulação das tabelas
    * @param CREATE, INSERT, UPDATE, DELETE
    */
    @Override
    public void onCreate(SQLiteDatabase bd) {
        bd.execSQL("CREATE TABLE livro(_id INTERGER PRIMARY KEY AUTOINCREMENT NOT NULL, titulo TEXT NOT NULL, tipo TEXT NOT NULL");
    }

    /*
    *
    * @info   Utilizado para versionar a base de dados
    * @param  1 = valor atual,  2 = valor novo
    */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        /*
        * bd.execSQL("DROP TABLE livro");
        * onCreate(bd);
        */
    }
}
